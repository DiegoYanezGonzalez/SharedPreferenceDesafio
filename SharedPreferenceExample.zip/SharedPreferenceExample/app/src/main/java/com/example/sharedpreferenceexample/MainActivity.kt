package com.example.sharedpreferenceexample

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
     //se declara y se puede inicializar despues
   //1 tener una variable de referencia para Shared Preferences
    lateinit var mSharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //2 Tener una value para el nombre del archivo de Shared Preferences
        val mFileName ="com.diego.sharedpreferenceexample"
        //3 Instanciar las Shared Preferences
        mSharedPreferences = getSharedPreferences(mFileName, Context.MODE_PRIVATE)

        var mUserKey="user"
        var mUser = "Diego.Yañez.@gmail.com"
        //aplly() es asincronico para archivos grandes
        mSharedPreferences.edit().putString(mUserKey,mUser).apply()

        var mUser2 ="dayTo@gmail.com"

        //sincronico se guarda en la ejecucuion - asincronico se guarda en un hilo por detras para no bloquear la interfaz de usuario

        mSharedPreferences.edit().putString(mUserKey,mUser2).apply()


        //Leer las sharedPreferences
        var mUserRead = mSharedPreferences.getString(mUserKey,"")
        Log.d("TAG", mUserRead!!)

        //Eliminar por Key
        mSharedPreferences.edit().remove(mUserKey)

        //Eliminar todos los campos
        mSharedPreferences.edit().remove(mUserRead)
    }
}